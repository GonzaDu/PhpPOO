-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 08-12-2017 a las 00:13:26
-- Versión del servidor: 5.7.19
-- Versión de PHP: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prueba`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE IF NOT EXISTS `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ci` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id`, `ci`, `Nombre`, `Apellido`, `Direccion`) VALUES
(1, 4455, 'Gonzalo', 'Fernandez', '18 de julio'),
(2, 6584, 'Claudia', 'Gonzalez', 'Rivera 2522'),
(3, 2354, 'Roberto', 'Fernandez', '20 de julio'),
(4, 3588, 'Matias', 'Macro', '8 de octubre'),
(5, 6899, 'Darwin', 'Cholo', 'Av italia'),
(6, 4577, 'Gonzalo', 'Garcia', 'Rambla');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detallecliente`
--

DROP TABLE IF EXISTS `detallecliente`;
CREATE TABLE IF NOT EXISTS `detallecliente` (
  `idCliente` int(11) NOT NULL,
  `Factura` int(11) NOT NULL,
  `Monto` double NOT NULL,
  `Fecha` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `detallecliente`
--

INSERT INTO `detallecliente` (`idCliente`, `Factura`, `Monto`, `Fecha`) VALUES
(1, 5565, 560, '2017-12-12'),
(1, 478, 880, '2017-12-04'),
(1, 5565, 560, '2017-12-12'),
(1, 478, 880, '2017-12-04'),
(1, 478, 880, '2017-12-04'),
(1, 478, 880, '2017-12-04'),
(1, 478, 880, '2017-12-04'),
(1, 5565, 560, '2017-12-12'),
(1, 478, 880, '2017-12-04'),
(1, 478, 880, '2017-12-04'),
(1, 478, 880, '2017-12-04'),
(1, 478, 880, '2017-12-04'),
(1, 478, 880, '2017-12-04'),
(2, 5565, 560, '2017-12-12'),
(2, 897, 400, '2017-12-04'),
(3, 465, 1500, '2017-12-04'),
(4, 335, 3550, '2017-12-04'),
(4, 1448, 777, '2017-12-04'),
(4, 97740, 111, '2017-12-04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Usuario` varchar(50) NOT NULL,
  `Contrasena` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `Usuario`, `Contrasena`) VALUES
(1, 'admin', 'admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
